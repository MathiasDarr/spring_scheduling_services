package org.mddarr.patientsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientsserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientsserviceApplication.class, args);
	}

}
